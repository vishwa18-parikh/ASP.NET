﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


public partial class ChangePassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter adp = new SqlDataAdapter();
        DataSet ds = new DataSet();
        cn.ConnectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=E:\WebSite4\App_Data\Database.mdf;Integrated Security=True";
        cn.Open();
        cmd.CommandText = "select *from registration where password='"+TextBox1.Text+"' and rid='"+ Session["id"].ToString() +"'";
        cmd.Connection = cn;
        cmd.ExecuteNonQuery();
        adp = new SqlDataAdapter(cmd);
        adp.Fill(ds);
        if(ds.Tables[0].Rows.Count==0)
        {
            Response.Write("Invalid Old Password");
        }
        else
        {
            cmd.CommandText = "update registration set password='"+ TextBox2.Text +"' where rid='" + Session["id"].ToString() + "'";
            cmd.ExecuteNonQuery();
            Response.Write("Your password changed successfully.");
        }
        cn.Close();
    }
}