﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;


public partial class Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string name = TextBox1.Text;
        string address = TextBox2.Text;
        string city = DropDownList1.Text;
        string gender = "";
        if(RadioButton1.Checked==true)
        {
            gender = RadioButton1.Text;
        }
        else
        {
            gender = RadioButton2.Text;
        }
        string loginid = TextBox3.Text;
        string password = TextBox4.Text;
        
        SqlConnection cn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        cn.ConnectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=E:\WebSite4\App_Data\Database.mdf;Integrated Security=True";
        cn.Open();

        cmd.CommandText = "insert into registration values('"+name+"','"+address+"','"+city+"','"+ gender +"','"+ loginid +"','"+ password +"')";
        cmd.Connection = cn;
        cmd.ExecuteNonQuery();
        cn.Close();
        Response.Write("Registered Successfully");
    }
}