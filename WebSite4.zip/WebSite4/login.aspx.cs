﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter adp = new SqlDataAdapter();
        DataSet ds = new DataSet();
        cn.ConnectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=E:\WebSite4\App_Data\Database.mdf;Integrated Security=True";
        cn.Open();
        cmd.CommandText = "select *from registration where loginid='"+ TextBox1.Text+"' and password='"+ TextBox2.Text +"'";
        cmd.Connection = cn;
        cmd.ExecuteNonQuery();
        adp = new SqlDataAdapter(cmd);
        adp.Fill(ds);
        if(ds.Tables[0].Rows.Count==0)
        {
            Response.Write("Invalid Loginid or password");
        }
        else
        {
            Session["name"] = ds.Tables[0].Rows[0].ItemArray[1].ToString();
            Session["id"] = ds.Tables[0].Rows[0].ItemArray[0].ToString();


            Response.Redirect("Welcome.aspx");
        }
        cn.Close();
    }
}