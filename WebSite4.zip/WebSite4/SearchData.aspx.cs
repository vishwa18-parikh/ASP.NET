﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


public partial class SearchData : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter adp = new SqlDataAdapter();
        DataSet ds = new DataSet();
        cn.ConnectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=E:\WebSite4\App_Data\Database.mdf;Integrated Security=True";
        cn.Open();
        cmd.CommandText = "select *from registration where loginid='"+TextBox1.Text+"'";
        cmd.Connection = cn;
        cmd.ExecuteNonQuery();
        adp = new SqlDataAdapter(cmd);
        adp.Fill(ds);
        if (ds.Tables[0].Rows.Count == 0)
        {
            Label1.Text = "Record Not Found";
        }
        else
        {
            Label1.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();
            Label1.Text =Label1.Text+"<br>"+ds.Tables[0].Rows[0].ItemArray[2].ToString();
            Label1.Text = Label1.Text + "<br>" + ds.Tables[0].Rows[0].ItemArray[3].ToString();
            Label1.Text = Label1.Text + "<br>" + ds.Tables[0].Rows[0].ItemArray[4].ToString();
            Label1.Text = Label1.Text + "<br>" + ds.Tables[0].Rows[0].ItemArray[5].ToString();
            Label1.Text = Label1.Text + "<br>" + ds.Tables[0].Rows[0].ItemArray[6].ToString();

        }

        cn.Close();
    }
}